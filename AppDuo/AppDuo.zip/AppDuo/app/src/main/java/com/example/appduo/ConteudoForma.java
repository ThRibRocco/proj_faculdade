package com.example.appduo;

public class ConteudoForma {
}
