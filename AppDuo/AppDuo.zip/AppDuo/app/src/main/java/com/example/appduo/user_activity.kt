package com.example.appduo

class user_activity {
}